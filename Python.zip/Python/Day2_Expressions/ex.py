#number mapping_Method:1
'''a = 10
b = 20
t = a
a = b 
b =t
print(a)
print(b)
'''

#number mapping_Method:2
a, b = 10, 20
a, b = b, a 
print(a)
print(b)

'''
a = 10
b = 20
a, b = a, b 
print(a)
print(b)
'''
#number mapping_Method:2
'''
a, b, c = c, b, a
a = 100
b = 100
c = 100
print (a)
print (b)
print (c)
'''

'''
a = 20+30-90*10/10*(20+30)%2
print(a)
'''





