#Defferent way to perform variables 
num1= 10
num2= 20
sum = num1 + num2
print ('the sum of {} and {} is {}'.format(num1, num2, sum))