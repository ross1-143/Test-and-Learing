'''a = 10
b = 20
c = a+b
print("sum of {} and {} is {}".format(a, b, c))
'''

'''num1 = 100
num2 = 200
num3 = num1+num2
print("sum of {} and {} is {}".format(num1,num2,num3))
'''

'''number1 = 200
number2 = 500
number3 = number2/number1
print("Division of {} / {} is {}" .format(number2, number1, number3))
'''

'''num1 = 200
num2 = 400
num3 = 600
num4 = 800
num5 = num2+num3+num4/num1+200
print("caliculation of {}+{}+{}/{}+200
 is {}" .format(num2, num3, num4, num1, num5))
'''
a = (10+20) 
b = (10*10)
c = 10*2
d = 100/10
e = 5+5
f = 50-10
g = (a+b+c+d+e+f) 
print("sum of the {} + {} + {} + {} + {} + {} is {}" .format(a, b , c, d, e, f, g))




