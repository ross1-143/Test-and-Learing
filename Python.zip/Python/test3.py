a= 10
b= 20
c = a + b
print ("Sum of {} and {} is {}". format(a,b,c))
